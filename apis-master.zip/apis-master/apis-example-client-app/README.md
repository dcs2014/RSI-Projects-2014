Example Client App 
======
The Example Client App is a very simple Spring web application that is developed for demo purposes. With the client app you can see what the typical flow is for real clients of your Resource Server. The prerequisites for seeing the client app in action are:

- The Authorization Server up and running
- The Example Resource Server up and running

See the documentation in the [README.md](https://github.com/OpenConextApps/apis/blob/master/README.md) in the root project for detailed instructions. 

