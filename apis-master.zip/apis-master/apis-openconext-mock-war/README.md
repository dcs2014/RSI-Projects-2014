OpenConext Mock War
======
This project can be ignored. It is used internally by the SAML Authenticator.