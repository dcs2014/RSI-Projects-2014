/*
emma.blunt
 */
INSERT INTO resourceowner (id, username, password)
VALUES (99999,'emma.blunt', 'cafebabe');